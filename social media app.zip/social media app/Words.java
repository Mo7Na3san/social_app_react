import java.util.Scanner;

public class Words {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String word1, word2;

        System.out.println("Enter word 1");
        word1 = input.next();

        System.out.println("Enter word 2");
        word2 = input.next();

        if (word1.equals(word2))
            System.out.println("Words are identical");
        else 
            System.out.println("Words are different");

        input.close();
    }
}
