// import checkLogin from "./posts-script";
// sign up button

let submitBtnSignUp = document.getElementById("submit-btn-sign-up");
let nameSignUp = document.getElementById("name-sign-up");
let userNameSignUp = document.getElementById("user-name-sign-up");
let userImgSignUp = document.getElementById("user-img-sign-up");
let passSignUp = document.getElementById("password-sign-up");
export const baseUrl = `https://tarmeezacademy.com/api/v1/`;
let signUpUrl = `${baseUrl}register`;

submitBtnSignUp.addEventListener("click", function () {
  let userDetails = new FormData();
  userDetails.append("username", userNameSignUp.value);
  userDetails.append("password", passSignUp.value);
  userDetails.append("name", nameSignUp.value);
  userDetails.append("image", userImgSignUp.files[0]);
  if (!userImgSignUp.files[0]) {
    alert("Please select an image file.");
    return;
  }
  const headers = {
    "Content-Type": "multipart/form-data",
  };
  axios
    .post(signUpUrl, userDetails, { headers: headers })
    .then(function (response) {
      console.log(response.data.token);
      localStorage.setItem("token", response.data.token);
      localStorage.setItem("user", JSON.stringify(response.data.user));
      console.log(response.data.user);
      console.log(response.data.token);
      // Select and hide the modal
      const modal = document.getElementById("sign-up-modal");
      const modalInstance = bootstrap.Modal.getInstance(modal);
      modalInstance.hide();
      if (response.data.token) {
        updateNavUi(response);
        updateUserIcon(response.data.user);
        alertStatus("Done, you signed up ..", "warning");
      }
    })
    .catch((error) => {
      console.log("Error response:", error.response.data.message); // Log entire error response
      if (error.response) {
        alertStatus(error.response.data.message, "danger"); // Show error message if available
      } else {
        alert("An unknown error occurred.");
      }
    });
});

// log in button
let userName = document.getElementById("user-name");
let password = document.getElementById("user-password");
let loginBtn = document.getElementById("submit-btn");
let loginUrl = `${baseUrl}login`;
function loginIfExist() {
  loginBtn.addEventListener("click", function () {
    axios
      .post(loginUrl, {
        username: userName.value,
        password: password.value,
      })
      .then(function (response) {
        console.log(response.data.token);
        localStorage.setItem("token", response.data.token);
        localStorage.setItem("user", JSON.stringify(response.data.user));
        // Select and hide the modal
        const modal = document.getElementById("login-modal");
        const modalInstance = bootstrap.Modal.getInstance(modal);
        modalInstance.hide();
        if (response.data.token) {
          updateNavUi(response);
          alertStatus("Nice, you logged in", "success");
        }
      })
      .catch((error) => {
        console.log("Error response:", error.response.data.message); // Log entire error response
        if (error.response) {
          alertStatus(error.response.data.message, "danger"); // Show error message if available
        } else {
          alert("An unknown error occurred.");
        }
      });
  });
}
document.addEventListener("DOMContentLoaded", function () {
  let localUserDetails = JSON.parse(localStorage.getItem("user"));
  if (localUserDetails) {
    updateNavUi(localUserDetails);
  }
});
loginIfExist();
// log out button
let logOutBtn = document.getElementById("log-out-btn");
logOutBtn.addEventListener("click", function () {
  updateNavUi();
  localStorage.clear();
  // accessLoginAction=false
  alertStatus("Logged out", "danger");
  checkLogin();
});

// update UI
function updateNavUi(user) {
  let ctrlSigning = document.getElementsByClassName("user-sign-in");
  let tokenValue = localStorage.getItem("token"); // Corrected: "token" as a string

  // Loop through each element in the collection
  for (let i = 0; i < ctrlSigning.length; i++) {
    if (tokenValue) {
      ctrlSigning[i].classList.toggle("logged-in");
      ctrlSigning[i].classList.toggle("logged-out");
    }
  }
  updateUserIcon(user);
  showNewPostIcon();
  checkLogin();
}

//show new post icon
function showNewPostIcon() {
  if (localStorage.token) {
    document.getElementById("add-new-post").classList.toggle("invisible");
  }
}

// update user photo after log in
function updateUserIcon(user = "Na3san") {
  let userIcon = document.getElementById("user-icon");
  if (user == "Na3san") {
    return (userIcon.innerHTML = "Na3san");
  }

  let userPhoto = user.profile_image;
  userPhoto =
    typeof userPhoto === "string" && userPhoto.trim() !== ""
      ? userPhoto
      : "./media/user-icon.jpg";
  userIcon.innerHTML = `
          <img
          src="${userPhoto}"
          alt="user profile picture"
          class="user-icon rounded-circle border border-3"
          />
  `;
}
// alert signing actions
export function alertStatus(msg, kind) {
  const alertPlaceholder = document.getElementById("liveAlertPlaceholder");
  const appendAlert = (message, type) => {
    const wrapper = document.createElement("div");
    wrapper.innerHTML = [
      `<div class="alert alert-${type} alert-dismissible" role="alert">`,
      `   <div>${message}</div>`,
      '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
      "</div>",
    ].join("");
    alertPlaceholder.append(wrapper);
    setTimeout(() => {
      wrapper.remove();
    }, 2500);
  };
  appendAlert(msg, kind);
}

// check if user login to ctrl edit btn
export function checkLogin() {
  let currentUser = JSON.parse(localStorage.getItem("user")) || {};
  if (!currentUser || Object.keys(currentUser).length === 0) {
    document.querySelectorAll(".post").forEach((post) => {
      let editButtonContainer = post.querySelector(".edit-post-box");
      editButtonContainer.style.display = "none";
    });
  } else {
    document.querySelectorAll(".post").forEach((post) => {
      const currentPostAuthorId = post.getAttribute("track-post-author-id");
      if (currentPostAuthorId == currentUser.id) {
        let editButtonContainer = post.querySelector(".edit-post-box");
        if (editButtonContainer) {
          editButtonContainer.style.display = "flex";
        }
      }
    });
  }
}
if (window.history.length > 1) {
  document.addEventListener("DOMContentLoaded", function () {
    let goBack = document.getElementById("go-back");
    goBack.addEventListener("click", function () {
      console.log("done");
      window.history.back();
    });
  });
}

// issues :
// 1- user profile img not save
