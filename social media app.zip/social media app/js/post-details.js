// import { baseUrl } from "./auth.js"; // Correct relative path
const baseUrl = `https://tarmeezacademy.com/api/v1/`;

const urlParams = new URLSearchParams(window.location.search);
const postId = urlParams.get("postId");

if (postId) {
  console.log(postId); // Output the postId
  const postUrl = `${baseUrl}posts/${postId}`;
  getSelectedPost(postUrl); // Correct URL format
} else {
  console.log("Post ID not found");
}

function getSelectedPost(url) {
  const selectedPost = document.getElementById("post-details-container");
  axios
    .get(url)
    .then((response) => {
      const post = response.data.data;
      console.log(response);
      let profileImageUrl =
        typeof post.author.profile_image === "string" &&
        post.author.profile_image.trim() !== ""
          ? post.author.profile_image
          : "./media/user-icon.jpg";

      let postImgUrl =
        typeof post.image === "string" && post.image.trim() !== ""
          ? post.image
          : "";
      let tagsHTML = "";
      for (const tag of post.tags) {
        tagsHTML += `<span class="tag-title p-2 bg-light-subtle shadow-sm rounded-5 mx-1">${tag.name}</span>`;
      }
      let commentsHTML = "";
      for (let i = 0; i < post.comments.length; i++) {
        let commentImageUrl =
          typeof post.comments[i].author.profile_image === "string" &&
          post.comments[i].author.profile_image.trim() !== ""
            ? post.comments[i].author.profile_image
            : "./media/user-icon.jpg";
        commentsHTML += `
        <div class='d-flex flex-row justify-content-between align-items-center w-100'>
        <div class="px-1">
        <img
           src="${commentImageUrl}"
           alt="user profile picture"
           class="user-icon rounded-circle border border-3 "
        />
        </div>
        <div class="p-1 border-bottom fs-5 w-100 position-relative">
        <h2 class="fs-4">${post.comments[i].author.name}</h2>
        <p>${post.comments[i].body}</p>
        <span class="position-absolute end-0 bottom-0">${getDateOnly(
          post.comments[i].author.created_at
        )}</span>
      </div></div>`;
      }
      let content = `
      <div class="">
        <div id="selected-post-container" class="posts-container rounded w-100">
          <div
            class="post p-3 mb-3 rounded content mx-auto"
            track-post-id="${post.id}"
          >
            <div
              class="user-info p-1 d-flex flex-wrap justify-content-between align-items-center"
            >
              <div class="d-flex flex-row align-items-center">
                <img
                  src="${profileImageUrl}"
                  alt="user profile picture"
                  class="user-icon rounded-circle border border-3"
                />
                <div class="d-flex flex-column px-2 py-0">
                  <h5 class="user-name py-0">${post.author.name}</h5>
                  <h5 class="user-code">@${post.author.username}</h5>
                </div>
              </div>
              <div class="p-2">${tagsHTML}</div>
            </div>
            <div class="post-info">
              <img src="${postImgUrl}" alt="" class="w-100 rounded" />
              <div class="post-text">
                <h2 class="post-title pt-3">
                  ${post.title != null ? post.title : ""}
                </h2>
                <p class="post-description">${post.body}</p>
              </div>
            </div>
            <p class="created-at py-0">${post.created_at}</p>
            <div
              class="post-reaction d-flex justify-content-around border-top p-3"
            >
              <i class="action-i fa-regular fa-heart"></i>
              <i class="action-i fa-solid fa-share"></i>
              <i class="action-i fa-solid fa-floppy-disk"></i>
            </div>
            <div class="border border-0">
              <div class="mb-3">
                <label for="message-text" class="col-form-label">Add comment:</label>
                <textarea class="form-control" id="text-comment"></textarea>
              </div>
                <div><button type="button" id="add-comment-btn" class="btn btn-primary">Add comment</button>
              </div>
              <div class="">
              <div
                class="post-reaction d-flex justify-content-around p-3"
              >
                <div
                  id="comments-container"
                  class="p-3 w-100 d-flex flex-column justify-content-between align-items-center"
                >
                  ${commentsHTML}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>      
      `;
      selectedPost.innerHTML += content;
      let txtComment = document.getElementById("text-comment");
      let commentBtn = document.getElementById("add-comment-btn");
      commentBtn.addEventListener("click", () => {
        let token = localStorage.getItem("token");
        const headers = {
          authorization: `Bearer ${token}`,
        };
        if (!token) {
          return alertStatus("You must login to add comments", "danger");
        }
        let comment = txtComment.value;
        let commentBody = {
          body: comment,
        };
        axios
          .post(`${baseUrl}posts/${postId}/comments`, commentBody, {
            headers: headers,
          })
          .then(function () {
            updateComments();
            txtComment.value = "";
          })
          .catch((error) => {
            console.log(error.message);
          });
      });
    })
    .catch((error) => {
      console.log(error.message);
    });
  function updateComments() {
    const commentsUrl = `${baseUrl}posts/${postId}`;
    let token = localStorage.getItem("token");
    const headers = {
      authorization: `Bearer ${token}`,
    };
    axios.get(commentsUrl, { headers: headers }).then((response) => {
      const comments = response.data.data.comments;
      let commentsHTML = "";
      for (let comment of comments) {
        let commentImageUrl =
          typeof comment.author.profile_image === "string" &&
          comment.author.profile_image.trim() !== ""
            ? comment.author.profile_image
            : "./media/user-icon.jpg";
        commentsHTML += `
        <div class='d-flex flex-row justify-content-between align-items-center w-100'>
        <div class="px-1">
        <img
           src="${commentImageUrl}"
           alt="user profile picture"
           class="user-icon rounded-circle border border-3 "
        />
        </div>
        <div class="p-1 border-bottom fs-5 w-100 position-relative">
        <h2 class="fs-4">${comment.author.name}</h2>
        <p>${comment.body}</p>
        <span class="position-absolute end-0 bottom-0">${getDateOnly(
          comment.author.created_at
        )}</span>
      </div></div>`;
        console.log(comment);
      }
      document.getElementById("comments-container").innerHTML = commentsHTML;
    });
  }
}
function getDateOnly(timestamp) {
  // Create a new Date object from the timestamp
  const date = new Date(timestamp);

  // Extract the year, month, and day
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0"); // Month is zero-based
  const day = String(date.getDate()).padStart(2, "0");

  // Return the date in YYYY-MM-DD format
  return `${year}-${month}-${day}`;
}
function alertStatus(msg, kind) {
  const alertPlaceholder = document.getElementById("liveAlertPlaceholder");
  const appendAlert = (message, type) => {
    const wrapper = document.createElement("div");
    wrapper.innerHTML = [
      `<div class="alert alert-${type} alert-dismissible" role="alert">`,
      `   <div>${message}</div>`,
      '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
      "</div>",
    ].join("");
    alertPlaceholder.append(wrapper);
    setTimeout(() => {
      wrapper.remove();
    }, 2500);
  };
  appendAlert(msg, kind);
}
