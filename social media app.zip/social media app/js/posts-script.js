import { baseUrl, checkLogin, alertStatus } from "./auth.js";
let currentPage = 1;
let loading = false;

function getPosts(page = 1, reload = true) {
  const postsContainer = document.getElementById("posts-container");
  axios
    .get(`${baseUrl}posts?limit=10&page=${page}`)
    .then((response) => {
      const posts = response.data.data;
      if (reload) {
        postsContainer.innerHTML = "";
      }
      for (const post of posts) {
        let profileImageUrl =
          typeof post.author.profile_image === "string" &&
          post.author.profile_image.trim() !== ""
            ? post.author.profile_image
            : "./media/user-icon.jpg";
        let postImgUrl =
          typeof post.image === "string" && post.image.trim() !== ""
            ? post.image
            : "";
        let tagsHTML = "";
        for (const tag of post.tags) {
          tagsHTML += ` <span class="tag-title p-2 bg-light-subtle shadow-sm rounded-5">
              ${tag.name}
            </span>`;
        }
        let content = `
        <div class="post p-3 mb-3 rounded content" track-post-id="${
          post.id
        }" track-post-author-id="${post.author.id}">
          <div class="user-info p-1 d-flex justify-content-between align-items-center">
            <div class="d-flex flex-row align-items-center" id="user-details" track-post-author-id="${
              post.author.id
            }">
              <img src="${profileImageUrl}" alt="user profile picture" class="user-icon rounded-circle border border-3" />
              <div class="d-flex flex-column px-2 py-0">
                <h5 class="user-name py-0">${post.author.name}</h5>
                <h5 class="user-code">@${post.author.username}</h5>
              </div>
            </div>
            <div class="d-flex justify-content-center align-items-center">
            <div class="justify-content-center align-items-center edit-btn-none edit-post-box flex-row"
            >
              <div class="d-flex justify-content-center align-items-center fs-3 m-1 ">
                <button id="delete-post" class="delete-btn p-2" track-delete-post-id=${
                  post.id
                }>
                  <i class="fa-solid fa-trash" ></i>
                </button>
              </div>
              <div class="d-flex justify-content-center align-items-center fs-3 m-1 ">
                <button  id="edit-post" class="edit-btn p-2" track-edit-post=${encodeURIComponent(
                  JSON.stringify(post)
                )}>
                   Edit <i class="fa-regular fa-pen-to-square"></i>
                </button>
              </div>
            </div>
            <div>${tagsHTML}</div></div>
          </div>
          <div class="post-info">
            <img src="${postImgUrl}" alt="" class="w-100 rounded" />
            <div class="post-text">
              <h2 class="post-title pt-3">${
                post.title != null ? post.title : ""
              }</h2>
              <p class="post-description">${post.body}</p>
            </div>
          </div>
          <p class="created-at py-0">${post.created_at}</p>
          <div class="post-reaction d-flex justify-content-around border-top pt-3">
            <i class="action-i fa-regular fa-comment"></i>
            <i class="action-i fa-regular fa-heart"></i>
            <i class="action-i fa-solid fa-share"></i>
            <i class="fa-regular fa-bookmark"></i>
          </div>
        </div>
      `;
        checkLogin();
        postsContainer.innerHTML += content;
      }
      loading = false;
    })
    .catch((error) => {
      console.log(error.message);
      loading = false; // Reset loading flag on error as well
    });
}

document.addEventListener("DOMContentLoaded", getPosts);

// handle clicks on the post : post page / reactions - edit - delete
document.addEventListener("DOMContentLoaded", getPosts);
document
  .getElementById("posts-container")
  .addEventListener("click", function (event) {
    // Check if the click was on a post
    if (event.target.closest(".post")) {
      const postId = event.target
        .closest(".post")
        .getAttribute("track-post-id");
      const editButton = event.target.closest("#edit-post");
      const deleteButton = event.target.closest("#delete-post");
      const userProfile = event.target.closest("#user-details");
      if (editButton) {
        event.stopPropagation(); // Prevent the click from triggering the post click
        // console.log(postId + " edit");
        const postDataString = decodeURIComponent(
          editButton.closest(".edit-btn").getAttribute("track-edit-post")
        );
        const postData = JSON.parse(postDataString);
        openEditModal(postData);
      } else if (deleteButton) {
        let selectedPost = deleteButton
          .closest(".delete-btn")
          .getAttribute("track-delete-post-id");
        deletePost(selectedPost);
      } else if (userProfile) {
        event.stopPropagation(); // Prevent the click from triggering the post click
        let clickedUserProfile = userProfile
          .closest("#user-details")
          .getAttribute("track-post-author-id");
        console.log(clickedUserProfile);
        window.location = `./profile.html?userId=${clickedUserProfile}`;
      } else {
        console.log(postId + " page");
        postClicked(postId);
      }
    }
  });

// Show selected post page , details and comments
export function postClicked(PostId) {
  // Redirect to post-details.html with the postId as a query parameter
  let clickedPostUrl = `./post-details.html?postId=${PostId}`;
  window.location = clickedPostUrl;
}

// open edit modal to edit the post
function openEditModal(post) {
  const postModal = new bootstrap.Modal(
    document.getElementById("edit-post-modal")
  );
  postModal.toggle();

  document.getElementById("edit-post-title").value = post.title;
  document.getElementById("edit-post-body").value = post.body;
  document
    .getElementById("edit-post-modal")
    .setAttribute("data-current-post-id", post.id);
}
// then , Event listener for submit button (attached once)
document
  .getElementById("submit-edit-post")
  .addEventListener("click", function () {
    const postId = document
      .getElementById("edit-post-modal")
      .getAttribute("data-current-post-id");
    const updatedContent = {
      body: document.getElementById("edit-post-body").value,
      title: document.getElementById("edit-post-title").value,
    };

    const token = localStorage.getItem("token");
    const headers = {
      authorization: `Bearer ${token}`,
    };

    axios
      .put(`${baseUrl}posts/${postId}`, updatedContent, { headers: headers })
      .then(() => {
        getPosts(); // Refresh posts to show updates

        let modalInstance = bootstrap.Modal.getInstance(
          document.getElementById("edit-post-modal")
        );
        const modal = document.getElementById("edit-post-modal");
        modalInstance = bootstrap.Modal.getInstance(modal);
        modalInstance.hide();
        alertStatus("Post updated", "success");
      })
      .catch((error) => {
        console.log(error.message);
        alertStatus(error.message);
      });
  });

//delete post function
function deletePost(postId) {
  let dltConfirm = confirm("Are you sure you want to delete this post ?");
  if (dltConfirm) {
    console.log("delete");
    const token = localStorage.getItem("token");
    const headers = {
      authorization: `Bearer ${token}`,
    };
    axios
      .delete(`${baseUrl}posts/${postId}`, { headers: headers })
      .then(() => {
        getPosts();
        alertStatus("Post deleted", "success");
      })
      .catch((error) => {
        console.log(error.message);
        alertStatus(error.message);
      });
  }
}
//add new post icon
const submitBtnCreatePost = document.getElementById("post-new-post");
if (submitBtnCreatePost) {
  submitBtnCreatePost.addEventListener("click", function () {
    let postText = document.getElementById("post-body");
    let postImg = document.getElementById("post-img");
    let postTitle = document.getElementById("post-title");
    let token = localStorage.getItem("token");
    let formData = new FormData();
    formData.append("body", postText.value);
    formData.append("title", postTitle.value);
    if (postImg.files.length > 0) {
      formData.append("image", postImg.files[0]);
    }
    const headers = {
      "Content-Type": "multipart/form-data",
      authorization: `Bearer ${token}`,
    };
    axios
      .post(`${baseUrl}posts`, formData, {
        headers: headers,
      })
      .then(function (response) {
        console.log(response);
        getPosts();
        // Select and hide the modal
        const modal = document.getElementById("create-post-modal");
        const modalInstance = bootstrap.Modal.getInstance(modal);
        modalInstance.hide();
        postText.value = "";
        postTitle.value = "";
        postImg.value = ""; // Reset file input to clear any selected file
      })
      .catch((error) => {
        console.log(error.message);
        alertStatus(error.message);
      });
  });
} else {
  console.log("Warning: 'add-new-post' element not found.");
}

//  infinite scroll
function handleScroll() {
  // Get scroll position, height, and viewport size
  const { scrollTop, scrollHeight, clientHeight } = document.documentElement;

  // Check if the scroll position is within 500px of the bottom
  if (scrollTop + clientHeight >= scrollHeight - 500 && !loading) {
    loadMoreContent();
  }
}
// Listen for the scroll event
window.addEventListener("scroll", handleScroll);

function loadMoreContent() {
  loading = true; // Set loading flag to true
  getPosts(currentPage++, false);
}

// SHOW USER PROFILE ==============================================================================
let profliePageLink = document.getElementById("profile-page-link");
profliePageLink.addEventListener("click", function () {
  let currentUser = JSON.parse(localStorage.getItem("user"));
  if (currentUser) {
    let currentUserPageUrl = `./profile.html?userId=${currentUser.id}`;
    profliePageLink.href = currentUserPageUrl;
  } else {
    console.log("user not login");
  }
});
