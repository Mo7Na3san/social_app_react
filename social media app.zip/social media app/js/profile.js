import { baseUrl, checkLogin, alertStatus } from "./auth.js";
// issues :
// cannot react to any post on profile page
// reach the profile page from any page of your app based on the user id
const urlParams = new URLSearchParams(window.location.search);
const userId = urlParams.get("userId");
function showUser() {
  const infoBox = document.getElementById("info-box");
  const userIntro = document.getElementById("user-intro");
  axios
    .get(`${baseUrl}users/${userId}`)
    .then((response) => {
      const user = response.data.data;
      let profileImageUrl =
        typeof user.profile_image === "string" &&
        user.profile_image.trim() !== ""
          ? user.profile_image
          : "./media/user-icon.jpg";
      let content = `
        <div
          class="d-flex flex-row justify-content-evenly align-items-center gap-3 flex-wrap"
        >
          <img src="${profileImageUrl}" alt="" class="profile-img" />
          <div class="">
            <h2>${user.name}</h2>
            <h5>@${user.username}</h5>
            <p>${user.email != null ? user.email : "No email exist"}</p>
          </div>
        </div>
        <div>
          <p><spsan class="counter-info">${user.posts_count}</spsan> ${
        user.posts_count > 1 ? "posts" : "post"
      }</p>
          <p><spsan class="counter-info">${user.comments_count}</spsan> ${
        user.comments_count > 1 ? "comments" : "comment"
      }</p>
        </div>
        `;
      infoBox.innerHTML = content;
      userIntro.innerHTML = `Welcome ${user.name}`;
    })
    .catch((error) => {
      console.error("Error fetching user data:", error);
    });
}

document.addEventListener("DOMContentLoaded", showUser);

// show user posts
function getUserPosts() {
  const postsContainer = document.getElementById("user-posts-container");
  axios
    .get(`${baseUrl}users/${userId}/posts`)
    .then((response) => {
      const posts = response.data.data;
      postsContainer.innerHTML = "";
      for (const post of posts) {
        let profileImageUrl =
          typeof post.author.profile_image === "string" &&
          post.author.profile_image.trim() !== ""
            ? post.author.profile_image
            : "./media/user-icon.jpg";
        let postImgUrl =
          typeof post.image === "string" && post.image.trim() !== ""
            ? post.image
            : "";
        let tagsHTML = "";
        for (const tag of post.tags) {
          tagsHTML += ` <span class="tag-title p-2 bg-light-subtle shadow-sm rounded-5">
              ${tag.name}
            </span>`;
        }
        let content = `
        <div class="post p-3 mb-3 rounded content" track-post-id="${
          post.id
        }" track-post-author-id="${post.author.id}">
          <div class="user-info p-1 d-flex justify-content-between align-items-center">
            <div class="d-flex flex-row align-items-center">
              <img src="${profileImageUrl}" alt="user profile picture" class="user-icon rounded-circle border border-3" />
              <div class="d-flex flex-column px-2 py-0">
                <h5 class="user-name py-0">${post.author.name}</h5>
                <h5 class="user-code">@${post.author.username}</h5>
              </div>
            </div>
            <div class="d-flex justify-content-center align-items-center">
            <div class="justify-content-center align-items-center edit-btn-none edit-post-box flex-row"
            >
              <div class="d-flex justify-content-center align-items-center fs-3 m-1 ">
                <button id="delete-post" class="delete-btn p-2" track-delete-post-id=${
                  post.id
                }>
                  <i class="fa-solid fa-trash" ></i>
                </button>
              </div>
              <div class="d-flex justify-content-center align-items-center fs-3 m-1 ">
                <button  id="edit-post" class="edit-btn p-2" track-edit-post=${encodeURIComponent(
                  JSON.stringify(post)
                )}>
                   Edit <i class="fa-regular fa-pen-to-square"></i>
                </button>
              </div>
            </div>
            <div>${tagsHTML}</div></div>
          </div>
          <div class="post-info">
            <img src="${postImgUrl}" alt="" class="w-100 rounded" />
            <div class="post-text">
              <h2 class="post-title pt-3">${
                post.title != null ? post.title : ""
              }</h2>
              <p class="post-description">${post.body}</p>
            </div>
          </div>
          <p class="created-at py-0">${post.created_at}</p>
          <div class="post-reaction d-flex justify-content-around border-top pt-3">
            <i class="action-i fa-regular fa-comment"></i>
            <i class="action-i fa-regular fa-heart"></i>
            <i class="action-i fa-solid fa-share"></i>
            <i class="fa-regular fa-bookmark"></i>
          </div>
        </div>
      `;
        checkLogin();
        postsContainer.innerHTML += content;
      }
    })
    .catch((error) => {
      console.log(error.message);
    });
}
getUserPosts();
// manage clicks on posts
document
  .getElementById("user-    posts-container")
  .addEventListener("click", function (event) {
    // Check if the click was on a post
    if (event.target.closest(".post")) {
      const postId = event.target
        .closest(".post")
        .getAttribute("track-post-id");
      const editButton = event.target.closest("#edit-post");
      const deleteButton = event.target.closest("#delete-post");
      const userProfile = event.target.closest("#user-details");
      if (editButton) {
        event.stopPropagation(); // Prevent the click from triggering the post click
        // console.log(postId + " edit");
        const postDataString = decodeURIComponent(
          editButton.closest(".edit-btn").getAttribute("track-edit-post")
        );
        const postData = JSON.parse(postDataString);
        openEditModal(postData);
      } else if (deleteButton) {
        let selectedPost = deleteButton
          .closest(".delete-btn")
          .getAttribute("track-delete-post-id");
        deletePost(selectedPost);
      } else if (userProfile) {
        event.stopPropagation(); // Prevent the click from triggering the post click
        let clickedUserProfile = userProfile
          .closest("#user-details")
          .getAttribute("track-post-author-id");
        console.log(clickedUserProfile);
        window.location = `./profile.html?userId=${clickedUserProfile}`;
      } else {
        console.log(postId + " page");
        postClicked(postId);
      }
    }
  });
